package sqldemo.b4a;

import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	private static final boolean fullScreen = false;
	private static final boolean includeTitle = true;
    public static WeakReference<Activity> previousOne;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		if (isFirst) {
			processBA = new BA(this.getApplicationContext(), null, null, "sqldemo.b4a", "main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                anywheresoftware.b4a.keywords.Common.Log("Killing previous instance (main).");
				p.finish();
			}
		}
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		mostCurrent = this;
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
		BA.handler.postDelayed(new WaitForLayout(), 5);

	}
	private static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
		activityBA = new BA(this, layout, processBA, "sqldemo.b4a", "main");
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        initializeProcessGlobals();		
        initializeGlobals();
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        anywheresoftware.b4a.keywords.Common.Log("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (mostCurrent == null || mostCurrent != this)
			return;
        processBA.setActivityPaused(false);
        anywheresoftware.b4a.keywords.Common.Log("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
		return true;
	}
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEvent(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyDown(keyCode, event);
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
		this.setIntent(intent);
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null) //workaround for emulator bug (Issue 2423)
            return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        anywheresoftware.b4a.keywords.Common.Log("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        processBA.setActivityPaused(true);
        mostCurrent = null;
        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
			if (mostCurrent == null || mostCurrent != activity.get())
				return;
			processBA.setActivityPaused(false);
            anywheresoftware.b4a.keywords.Common.Log("** Activity (main) Resume **");
		    processBA.raiseEvent(mostCurrent._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}

public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.sql.SQL _sql1 = null;
public static anywheresoftware.b4a.sql.SQL.CursorWrapper _cursor1 = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtusername = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtpassword = null;
public anywheresoftware.b4a.objects.ListViewWrapper _lvdb = null;
public anywheresoftware.b4a.objects.ButtonWrapper _cmdadd = null;
public anywheresoftware.b4a.objects.ButtonWrapper _cmddelete = null;
public anywheresoftware.b4a.objects.ButtonWrapper _cmdedit = null;
public static String _id = "";
public static String  _activity_create(boolean _firsttime) throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
 //BA.debugLineNum = 23;BA.debugLine="Activity.LoadLayout(\"main\")";
mostCurrent._activity.LoadLayout("main",mostCurrent.activityBA);
 //BA.debugLineNum = 24;BA.debugLine="If File.Exists(File.DirInternal,\"db.sql\") = False Then";
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"db.sql")==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 25;BA.debugLine="File.Copy(File.DirAssets,\"db.sql\",File.DirInternal,\"db.sql\")";
anywheresoftware.b4a.keywords.Common.File.Copy(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"db.sql",anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"db.sql");
 };
 //BA.debugLineNum = 28;BA.debugLine="If SQL1.IsInitialized = False Then";
if (_sql1.IsInitialized()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 29;BA.debugLine="SQL1.Initialize(File.DirInternal, \"db.sql\", False)";
_sql1.Initialize(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"db.sql",anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 32;BA.debugLine="DBload";
_dbload();
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
 //BA.debugLineNum = 41;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
 //BA.debugLineNum = 37;BA.debugLine="Sub Activity_Resume";
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return "";
}
public static String  _cmdadd_click() throws Exception{
int _i = 0;
int _newid = 0;
 //BA.debugLineNum = 60;BA.debugLine="Sub cmdAdd_Click";
 //BA.debugLineNum = 62;BA.debugLine="If txtUsername.Text = \"\" OR txtPassword.Text = \"\" Then";
if ((mostCurrent._txtusername.getText()).equals("") || (mostCurrent._txtpassword.getText()).equals("")) { 
 //BA.debugLineNum = 63;BA.debugLine="Msgbox(\"You have to enter all fields\",\"Missed data field\")";
anywheresoftware.b4a.keywords.Common.Msgbox("You have to enter all fields","Missed data field",mostCurrent.activityBA);
 }else {
 //BA.debugLineNum = 67;BA.debugLine="cursor1 = SQL1.ExecQuery(\"SELECT ID FROM tblUsers\")";
_cursor1.setObject((android.database.Cursor)(_sql1.ExecQuery("SELECT ID FROM tblUsers")));
 //BA.debugLineNum = 68;BA.debugLine="If cursor1.RowCount > 0 Then";
if (_cursor1.getRowCount()>0) { 
 //BA.debugLineNum = 69;BA.debugLine="For i = 0 To cursor1.RowCount - 1";
{
final double step45 = 1;
final double limit45 = (int)(_cursor1.getRowCount()-1);
for (_i = (int)(0); (step45 > 0 && _i <= limit45) || (step45 < 0 && _i >= limit45); _i += step45) {
 //BA.debugLineNum = 70;BA.debugLine="cursor1.Position = i";
_cursor1.setPosition(_i);
 //BA.debugLineNum = 72;BA.debugLine="Dim NewID As Int";
_newid = 0;
 //BA.debugLineNum = 73;BA.debugLine="NewID = cursor1.GetInt(\"ID\")";
_newid = _cursor1.GetInt("ID");
 }
};
 };
 //BA.debugLineNum = 77;BA.debugLine="NewID = NewID +1 ' add 1 to the ID number to make a new ID field";
_newid = (int)(_newid+1);
 //BA.debugLineNum = 78;BA.debugLine="SQL1.ExecNonQuery(\"INSERT INTO tblUsers VALUES('\" & NewID & \"','\" & txtUsername.Text & \"','\" & txtPassword.Text & \"')\")";
_sql1.ExecNonQuery("INSERT INTO tblUsers VALUES('"+BA.NumberToString(_newid)+"','"+mostCurrent._txtusername.getText()+"','"+mostCurrent._txtpassword.getText()+"')");
 //BA.debugLineNum = 79;BA.debugLine="DBload";
_dbload();
 //BA.debugLineNum = 80;BA.debugLine="txtUsername.Text = \"\"";
mostCurrent._txtusername.setText((Object)(""));
 //BA.debugLineNum = 81;BA.debugLine="txtPassword.Text = \"\"";
mostCurrent._txtpassword.setText((Object)(""));
 //BA.debugLineNum = 82;BA.debugLine="txtUsername.RequestFocus";
mostCurrent._txtusername.RequestFocus();
 };
 //BA.debugLineNum = 86;BA.debugLine="End Sub";
return "";
}
public static String  _cmddelete_click() throws Exception{
 //BA.debugLineNum = 87;BA.debugLine="Sub cmdDelete_Click";
 //BA.debugLineNum = 90;BA.debugLine="SQL1.ExecNonQuery(\"DELETE FROM tblUsers where ID = '\" &ID & \"' \")";
_sql1.ExecNonQuery("DELETE FROM tblUsers where ID = '"+mostCurrent._id+"' ");
 //BA.debugLineNum = 91;BA.debugLine="DBload";
_dbload();
 //BA.debugLineNum = 92;BA.debugLine="txtUsername.Text = \"\"";
mostCurrent._txtusername.setText((Object)(""));
 //BA.debugLineNum = 93;BA.debugLine="txtPassword.Text =\"\"";
mostCurrent._txtpassword.setText((Object)(""));
 //BA.debugLineNum = 95;BA.debugLine="End Sub";
return "";
}
public static String  _cmdedit_click() throws Exception{
 //BA.debugLineNum = 113;BA.debugLine="Sub cmdEdit_Click";
 //BA.debugLineNum = 114;BA.debugLine="If txtUsername.Text = \"\" OR txtPassword.Text = \"\" Then";
if ((mostCurrent._txtusername.getText()).equals("") || (mostCurrent._txtpassword.getText()).equals("")) { 
 //BA.debugLineNum = 115;BA.debugLine="Msgbox(\"Select item to edit\",\"Missed data item\")";
anywheresoftware.b4a.keywords.Common.Msgbox("Select item to edit","Missed data item",mostCurrent.activityBA);
 }else {
 //BA.debugLineNum = 117;BA.debugLine="SQL1.ExecNonQuery(\"UPDATE tblUsers set Username ='\"& txtUsername.text &\"',Password ='\"& txtPassword.text &\"' WHERE ID = \" & ID)";
_sql1.ExecNonQuery("UPDATE tblUsers set Username ='"+mostCurrent._txtusername.getText()+"',Password ='"+mostCurrent._txtpassword.getText()+"' WHERE ID = "+mostCurrent._id);
 //BA.debugLineNum = 118;BA.debugLine="DBload";
_dbload();
 };
 //BA.debugLineNum = 121;BA.debugLine="End Sub";
return "";
}
public static String  _cmdexit_click() throws Exception{
 //BA.debugLineNum = 122;BA.debugLine="Sub cmdExit_Click";
 //BA.debugLineNum = 123;BA.debugLine="Activity.finish";
mostCurrent._activity.Finish();
 //BA.debugLineNum = 124;BA.debugLine="End Sub";
return "";
}
public static String  _dbload() throws Exception{
int _i = 0;
 //BA.debugLineNum = 45;BA.debugLine="Sub DBload";
 //BA.debugLineNum = 46;BA.debugLine="LVDb.Clear'need to clear the list";
mostCurrent._lvdb.Clear();
 //BA.debugLineNum = 48;BA.debugLine="cursor1 = SQL1.ExecQuery(\"SELECT * FROM tblUsers\")";
_cursor1.setObject((android.database.Cursor)(_sql1.ExecQuery("SELECT * FROM tblUsers")));
 //BA.debugLineNum = 49;BA.debugLine="For i = 0 To cursor1.RowCount - 1";
{
final double step30 = 1;
final double limit30 = (int)(_cursor1.getRowCount()-1);
for (_i = (int)(0); (step30 > 0 && _i <= limit30) || (step30 < 0 && _i >= limit30); _i += step30) {
 //BA.debugLineNum = 50;BA.debugLine="cursor1.Position = i";
_cursor1.setPosition(_i);
 //BA.debugLineNum = 51;BA.debugLine="LVDb.AddSingleLine(cursor1.GetString(\"ID\")& \"|\" &cursor1.GetString(\"Username\")& \" | \" & cursor1.GetString(\"Password\"))";
mostCurrent._lvdb.AddSingleLine(_cursor1.GetString("ID")+"|"+_cursor1.GetString("Username")+" | "+_cursor1.GetString("Password"));
 //BA.debugLineNum = 52;BA.debugLine="LVDb.SingleLineLayout.ItemHeight = 20";
mostCurrent._lvdb.getSingleLineLayout().setItemHeight((int)(20));
 //BA.debugLineNum = 53;BA.debugLine="LVDb.SingleLineLayout.Label.TextSize = 10";
mostCurrent._lvdb.getSingleLineLayout().Label.setTextSize((float)(10));
 //BA.debugLineNum = 54;BA.debugLine="LVDb.SingleLineLayout.label.TextColor = Colors.Black";
mostCurrent._lvdb.getSingleLineLayout().Label.setTextColor(anywheresoftware.b4a.keywords.Common.Colors.Black);
 //BA.debugLineNum = 55;BA.debugLine="LVDb.SingleLineLayout.label.Color = Colors.White";
mostCurrent._lvdb.getSingleLineLayout().Label.setColor(anywheresoftware.b4a.keywords.Common.Colors.White);
 }
};
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return "";
}

public static void initializeProcessGlobals() {
    
    if (processGlobalsRun == false) {
	    processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}

public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
return vis;}
public static String  _globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 9;BA.debugLine="Dim txtUsername As EditText";
mostCurrent._txtusername = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Dim txtPassword As EditText";
mostCurrent._txtpassword = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 11;BA.debugLine="Dim LVDb As ListView";
mostCurrent._lvdb = new anywheresoftware.b4a.objects.ListViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Dim cmdAdd As Button";
mostCurrent._cmdadd = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Dim cmdDelete As Button";
mostCurrent._cmddelete = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Dim cmdEdit As Button";
mostCurrent._cmdedit = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Dim ID As String";
mostCurrent._id = "";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public static String  _lvdb_itemclick(int _position,Object _value) throws Exception{
String _idvalue = "";
int _countit = 0;
int _i = 0;
 //BA.debugLineNum = 97;BA.debugLine="Sub LVDb_ItemClick (Position As Int, Value As Object)' click on the entry in the list";
 //BA.debugLineNum = 98;BA.debugLine="Dim idvalue As String";
_idvalue = "";
 //BA.debugLineNum = 99;BA.debugLine="Dim countIt As Int";
_countit = 0;
 //BA.debugLineNum = 101;BA.debugLine="idvalue = Value";
_idvalue = String.valueOf(_value);
 //BA.debugLineNum = 102;BA.debugLine="countIt = idvalue.IndexOf(\"|\") 'find location of sperator";
_countit = _idvalue.indexOf("|");
 //BA.debugLineNum = 103;BA.debugLine="idvalue = idvalue.SubString2(0,countIt) 'find first part of label text";
_idvalue = _idvalue.substring((int)(0),_countit);
 //BA.debugLineNum = 104;BA.debugLine="ID = idvalue";
mostCurrent._id = _idvalue;
 //BA.debugLineNum = 105;BA.debugLine="cursor1 = SQL1.ExecQuery(\"SELECT * FROM tblUsers where ID = '\" & ID & \"' \")";
_cursor1.setObject((android.database.Cursor)(_sql1.ExecQuery("SELECT * FROM tblUsers where ID = '"+mostCurrent._id+"' ")));
 //BA.debugLineNum = 106;BA.debugLine="For i = 0 To cursor1.RowCount - 1";
{
final double step73 = 1;
final double limit73 = (int)(_cursor1.getRowCount()-1);
for (_i = (int)(0); (step73 > 0 && _i <= limit73) || (step73 < 0 && _i >= limit73); _i += step73) {
 //BA.debugLineNum = 107;BA.debugLine="cursor1.Position = i";
_cursor1.setPosition(_i);
 //BA.debugLineNum = 108;BA.debugLine="txtUsername.text=cursor1.getString(\"Username\")";
mostCurrent._txtusername.setText((Object)(_cursor1.GetString("Username")));
 //BA.debugLineNum = 109;BA.debugLine="txtPassword.text=cursor1.getString(\"Password\")";
mostCurrent._txtpassword.setText((Object)(_cursor1.GetString("Password")));
 }
};
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Dim SQL1 As SQL";
_sql1 = new anywheresoftware.b4a.sql.SQL();
 //BA.debugLineNum = 4;BA.debugLine="Dim cursor1 As Cursor";
_cursor1 = new anywheresoftware.b4a.sql.SQL.CursorWrapper();
 //BA.debugLineNum = 6;BA.debugLine="End Sub";
return "";
}
}
